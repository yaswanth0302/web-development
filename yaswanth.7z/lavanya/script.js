
// script.js

const API_URL = 'https://jsonplaceholder.typicode.com/users'; // Replace with your API endpoint
const form = document.getElementById('data-form');
const tableBody = document.querySelector('#data-table tbody');
const messageBox = document.getElementById('message');

// Variable to track the next ID for newly added records
let nextId = 1;

// Fetch and display data on page load
window.onload = fetchAndDisplayData;

// Add record
form.addEventListener('submit', async (e) => {
  e.preventDefault();

  const name = document.getElementById('name').value;
  const email = document.getElementById('email').value;

  // Use nextId as the new record ID
  const newId = nextId++;

  const response = await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, email }),
  });

  if (response.ok) {
    const newData = await response.json();
    displayMessage('Record added successfully!', 'success');
    addTableRow({ ...newData, id: newId }); // Use the incremented ID
    form.reset();
  } else {
    displayMessage('Failed to add record.', 'error');
  }
});

// Fetch and display data
async function fetchAndDisplayData() {
  const response = await fetch(API_URL);
  if (response.ok) {
    const data = await response.json();
    tableBody.innerHTML = '';
    data.forEach((item, index) => {
      // Assign an ID to each fetched record using an incrementing index
      addTableRow({ ...item, id: index + 1 });
      nextId = index + 2; // Update nextId to ensure it's unique for the next added record
    });
  } else {
    displayMessage('Failed to fetch data.', 'error');
  }
}

// Add a row to the table
function addTableRow({ id, name, email }) {
  const row = document.createElement('tr');
  row.setAttribute('data-id', id);
  row.innerHTML = `
    <td>${id}</td>
    <td class="name">${name}</td>
    <td class="email">${email}</td>
    <td class="actions">
      <button class="edit">Edit</button>
      <button class="delete">Delete</button>
    </td>
  `;

  // Attach event listeners for edit and delete buttons
  row.querySelector('.edit').addEventListener('click', () => editRecord(row, id, name, email));
  row.querySelector('.delete').addEventListener('click', () => deleteRecord(row, id));

  tableBody.appendChild(row);
}

// Edit a record
function editRecord(row, id, currentName, currentEmail) {
  const nameCell = row.querySelector('.name');
  const emailCell = row.querySelector('.email');
  const actionsCell = row.querySelector('.actions');

  // Replace text content with input fields
  nameCell.innerHTML = `<input type="text" value="${currentName}" class="edit-name">`;
  emailCell.innerHTML = `<input type="text" value="${currentEmail}" class="edit-email">`;
  actionsCell.innerHTML = `
    <button class="save">Save</button>
    <button class="cancel">Cancel</button>
  `;

  // Attach event listeners for save and cancel buttons
  actionsCell.querySelector('.save').addEventListener('click', () => saveEdit(row, id));
  actionsCell.querySelector('.cancel').addEventListener('click', () => cancelEdit(row, currentName, currentEmail));
}

// Save the edited record
async function saveEdit(row, id) {
  const newName = row.querySelector('.edit-name').value;
  const newEmail = row.querySelector('.edit-email').value;

  const response = await fetch(`${API_URL}/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: newName, email: newEmail }),
  });

  if (response.ok) {
    displayMessage('Record updated successfully!', 'success');
    row.querySelector('.name').textContent = newName;
    row.querySelector('.email').textContent = newEmail;
    restoreActions(row, id, newName, newEmail);
  } else {
    displayMessage('Failed to update record.', 'error');
  }
}

// Cancel edit
function cancelEdit(row, originalName, originalEmail) {
  row.querySelector('.name').textContent = originalName;
  row.querySelector('.email').textContent = originalEmail;
  restoreActions(row, originalName, originalEmail);
}

// Restore default action buttons
function restoreActions(row, id, name, email) {
  const actionsCell = row.querySelector('.actions');
  actionsCell.innerHTML = `
    <button class="edit">Edit</button>
    <button class="delete">Delete</button>
  `;
  actionsCell.querySelector('.edit').addEventListener('click', () => editRecord(row, id, name, email));
  actionsCell.querySelector('.delete').addEventListener('click', () => deleteRecord(row, id));
}

// Delete a record
async function deleteRecord(row, id) {
  const confirmDelete = confirm('Are you sure you want to delete this record?');
  if (confirmDelete) {
    const response = await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
    if (response.ok) {
      displayMessage('Record deleted successfully!', 'success');
      row.remove();
    } else {
      displayMessage('Failed to delete record.', 'error');
    }
  }
}

// Display a message
function displayMessage(message, type) {
  messageBox.textContent = message;
  messageBox.style.color = type === 'success' ? 'green' : 'red';
  setTimeout(() => (messageBox.textContent = ''), 3000);
}
